require 'minitest/autorun'
require_relative 'lib/executor.rb'

class ExecutorTest < Minitest::Test
  def setup
    @executor = Executor.new
  end

  def test_sum_of_first_n_numbers
    result = @executor.evaluate([:call, "sum_of_first_n_numbers", [5]])
    assert_equal 15, result
  end

  def test_factorial
    result = @executor.evaluate([:call, "factorial", [5]])
    assert_equal 120, result
  end

  def test_gcd
    result = @executor.evaluate([:call, "gcd", [48, 18]])
    assert_equal 6, result
  end

  def test_reverse_number
    result = @executor.evaluate([:call, "reverse_number", [1234]])
    assert_equal 4321, result
  end

  def test_prime_check
    result = @executor.evaluate([:call, "prime_check", [7]])
    assert_equal true, result
  end

  def test_palindrome_check
    result = @executor.evaluate([:call, "palindrome_check", ["racecar"]])
    assert_equal true, result
  end

  def test_largest_digit
    result = @executor.evaluate([:call, "largest_digit", [5836]])
    assert_equal 8, result
  end

  def test_sum_of_digits
    result = @executor.evaluate([:call, "sum_of_digits", [1234]])
    assert_equal 10, result
  end

  def test_multiplication_table
    result = @executor.evaluate([:call, "multiplication_table", [3]])
    expected = [
      "3 * 1 = 3",
      "3 * 2 = 6",
      "3 * 3 = 9",
      "3 * 4 = 12",
      "3 * 5 = 15",
      "3 * 6 = 18",
      "3 * 7 = 21",
      "3 * 8 = 24",
      "3 * 9 = 27",
      "3 * 10 = 30"
    ]
    assert_equal expected, result
  end

  def test_fibonacci
    result = @executor.evaluate([:call, "fibonacci", [5]])
    assert_equal [0, 1, 1, 2, 3], result
  end

  def test_variable_assignment_and_retrieval
    @executor.execute([[:assign, "x", 10]])
    result = @executor.evaluate("x")
    assert_equal 10, result
  end

  def test_arithmetic_operations
    @executor.execute([[:assign, "x", 10], [:assign, "y", 5]])
    result = @executor.evaluate([:+, "x", "y"])
    assert_equal 15, result
  end

  def test_if_statement
    statements = [
      [:assign, "x", 10],
      [:if, [:>, "x", 5], [[:assign, "y", 20]]]
    ]
    @executor.execute(statements)
    result = @executor.evaluate("y")
    assert_equal 20, result
  end

  def test_while_loop
    statements = [
      [:assign, "x", 0],
      [:while, [:<, "x", 3], [[:assign, "x", [:+, "x", 1]]]]
    ]
    @executor.execute(statements)
    result = @executor.evaluate("x")
    assert_equal 3, result
  end
end

require 'minitest/autorun'
require_relative 'lib/tokenizerrb'

class TokenizerTest < Minitest::Test
  def test_tokenize_simple_assignment
    tokenizer = Tokenizer.new("x = 10;")
    expected_tokens = ["x", "=", "10", ";"]
    assert_equal expected_tokens, tokenizer.tokens
  end

  def test_tokenize_arithmetic_expression
    tokenizer = Tokenizer.new("x = 5 + 3;")
    expected_tokens = ["x", "=", "5", "+", "3", ";"]
    assert_equal expected_tokens, tokenizer.tokens
  end

  def test_tokenize_relational_operators
    tokenizer = Tokenizer.new("if (x > 5) { print x; }")
    expected_tokens = ["if", "(", "x", ">", "5", ")", "{", "print", "x", ";", "}"]
    assert_equal expected_tokens, tokenizer.tokens
  end

  def test_tokenize_logical_operators
    tokenizer = Tokenizer.new("x = (a && b) || c;")
    expected_tokens = ["x", "=", "(", "a", "&&", "b", ")", "||", "c", ";"]
    assert_equal expected_tokens, tokenizer.tokens
  end

  def test_tokenize_empty_input
    tokenizer = Tokenizer.new("")
    expected_tokens = []
    assert_equal expected_tokens, tokenizer.tokens
  end

  def test_tokenize_invalid_input
    tokenizer = Tokenizer.new("x = 5 ^ 2;")
    expected_tokens = ["x", "=", "5", "^", "2", ";"]
    assert_equal expected_tokens, tokenizer.tokens
  end
end

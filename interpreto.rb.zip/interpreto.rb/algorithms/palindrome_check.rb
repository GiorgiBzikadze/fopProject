# Check if a Number is Palindrome (Beginner-friendly)
def palindrome?(n)
  original = n
  reversed = 0
  while n > 0
    digit = n % 10
    reversed = reversed * 10 + digit
    n /= 10
  end
  return original == reversed
end

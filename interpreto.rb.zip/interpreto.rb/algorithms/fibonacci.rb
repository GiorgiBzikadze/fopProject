# Nth Fibonacci Number Algorithm (Beginner-friendly)
def fibonacci(n)
  a = 0
  b = 1
  i = 1
  while i < n
    temp = a
    a = b
    b = temp + b
    i += 1
  end
  return a
end

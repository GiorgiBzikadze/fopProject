# Sum of First N Numbers Algorithm (Beginner-friendly)
def sum_of_first_n_numbers(n)
  sum = 0
  i = 1
  while i <= n
    sum += i
    i += 1
  end
  return sum
end

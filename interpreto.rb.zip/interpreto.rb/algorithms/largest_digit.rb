# Find the Largest Digit in a Number (Beginner-friendly)
def largest_digit(n)
  largest = 0
  while n > 0
    digit = n % 10
    if digit > largest
      largest = digit
    end
    n /= 10
  end
  return largest
end

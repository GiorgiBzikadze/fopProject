# Reverse a Number Algorithm (Beginner-friendly)
def reverse_number(n)
  reversed = 0
  while n > 0
    digit = n % 10
    reversed = reversed * 10 + digit
    n /= 10
  end
  return reversed
end

# GCD of Two Numbers Algorithm (Beginner-friendly version of Euclidean algorithm)
def gcd(a, b)
  while a != b
    if a > b
      a -= b
    else
      b -= a
    end
  end
  return a
end

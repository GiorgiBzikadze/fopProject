# Multiplication Table Algorithm (Beginner-friendly)
def multiplication_table(n)
  i = 1
  while i <= 10
    puts n * i
    i += 1
  end
end




require_relative 'test/tokenizer_test.rb'
require_relative 'lib/tokenizer'
require_relative 'lib/parser'
require_relative 'lib/executor'



require_relative 'algorithms/sum_of_first_n_numbers'
require_relative 'algorithms/factorial'
require_relative 'algorithms/gcd'
require_relative 'algorithms/reverse_number'
require_relative 'algorithms/prime_check'
require_relative 'algorithms/palindrome_check'
require_relative 'algorithms/largest_digit'
require_relative 'algorithms/sum_of_digits'
require_relative 'algorithms/multiplication_table'
require_relative 'algorithms/fibonacci'

if __FILE__ == $0
  puts "Enter your program (type 'END' on a new line to finish):"
  input = ""
  
 
  while (line = gets.chomp) != "END"
    input += line + "\n"
  end
  
  tokenizer = Tokenizer.new(input)
  tokens = tokenizer.tokens
  puts "Tokens: #{tokens.inspect}"
  
  
  parser = Parser.new(tokens)
  program = parser.parse
  puts "Parsed Program: #{program.inspect}"

  
  executor = Executor.new
  executor.execute(program)
end

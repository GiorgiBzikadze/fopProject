class Parser
  def initialize(tokens)
    @tokens = tokens
    @position = 0
  end

  def parse
    statements = []
    while @position < @tokens.size
      statements << parse_statement
    end
    statements
  end

  def parse_statement
    if match?("print")
      consume("print")
      expr = parse_expression
      consume(";")
      [:print, expr]
    elsif match?(/\w+/) && lookahead == "="
      var = consume(/\w+/)
      consume("=")
      expr = parse_expression
      consume(";")
      [:assign, var, expr]
    elsif match?(/\w+/) && lookahead == "(" 
      func_name = consume(/\w+/)
      consume("(")
      args = []
      until match?(")")
        args << parse_expression
        consume(",") if match?(",") 
      end
      consume(")")
      [:call, func_name, args]
    elsif match?("while")
      consume("while")
      consume("(")
      condition = parse_expression
      consume(")")
      consume("{")
      body = []
      until match?("}")
        body << parse_statement
      end
      consume("}")
      [:while, condition, body]
    elsif match?("if")
      consume("if")
      consume("(")
      condition = parse_expression
      consume(")")
      consume("{")
      body = []
      until match?("}")
        body << parse_statement
      end
      consume("}")
      [:if, condition, body]
    else
      raise "Unexpected token: #{@tokens[@position]}"
    end
  end

  def parse_expression
    left = parse_term
    while match?(/[+\-]/)
      op = consume(/[+\-]/)
      right = parse_term
      left = [op, left, right]
    end
    left
  end

  def parse_term
    left = parse_factor
    while match?(/[*\/%]/)
      op = consume(/[*\/%]/)
      right = parse_factor
      left = [op, left, right]
    end
    left
  end

  def parse_factor
    if match?(/\d+/)
      consume(/\d+/).to_i
    elsif match?(/\w+/)
      identifier = consume(/\w+/)
      if match?("(") 
        consume("(")
        args = []
        until match?(")")
          args << parse_expression
          consume(",") if match?(",") 
        end
        consume(")")
        [:call, identifier, args]
      else
        identifier 
      end
    elsif match?(/\(/)
      consume("(")
      expr = parse_expression
      consume(")")
      expr
    else
      raise "Unexpected token: #{@tokens[@position]}"
    end
  end

  def match?(pattern)
    case pattern
    when String
      @tokens[@position] == pattern
    when Regexp
      @tokens[@position] =~ pattern
    else
      false
    end
  end

  def lookahead
    @tokens[@position + 1]
  end

  def consume(pattern)
    if match?(pattern)
      token = @tokens[@position]
      @position += 1
      token
    else
      raise "Expected #{pattern}, got #{@tokens[@position]}"
    end
  end
end

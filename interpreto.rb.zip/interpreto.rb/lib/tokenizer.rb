class Tokenizer
  attr_reader :tokens

  def initialize(input)
    @tokens = input.scan(/\w+|[{};=+\-*\/%()<>!&|]=?|&&|\|\|/)
  end
end

class Executor
  def initialize
    @variables = {}
    @functions = {
      "sum_of_first_n_numbers" => ->(n) { (1..n).sum },
      "factorial" => ->(n) { (1..n).reduce(1, :*) || 1 },
      "gcd" => ->(a, b) { a.gcd(b) },
      "reverse_number" => ->(n) { n.to_s.reverse.to_i },
      "prime_check" => ->(n) { require 'prime'; Prime.prime?(n) },
      "palindrome_check" => ->(str) { str == str.reverse },
      "largest_digit" => ->(n) { n.to_s.chars.map(&:to_i).max },
      "sum_of_digits" => ->(n) { n.to_s.chars.map(&:to_i).sum },
      "multiplication_table" => ->(n) { (1..10).map { |i| "#{n} * #{i} = #{n * i}" } },
      "fibonacci" => ->(n) { (0..n-1).inject([0, 1]) { |fib| fib << fib[-2] + fib[-1] }[0...n] }
    }
  end

  def execute(statements)
    statements.each do |statement|
      case statement[0]
      when :print
        puts evaluate(statement[1])
      when :assign
        @variables[statement[1]] = evaluate(statement[2])
      when :while
        while evaluate(statement[1])
          execute(statement[2])
        end
      when :if
        if evaluate(statement[1])
          execute(statement[2])
        end
      else
        raise "Unknown statement: #{statement.inspect}"
      end
    end
  end

  def evaluate(expression)
    case expression
    when Integer
      expression
    when String
      @variables[expression] || raise("Undefined variable: #{expression}")
    when Array
      case expression[0]
      when :call
        func_name = expression[1]
        args = expression[2].map { |arg| evaluate(arg) }
        if @functions.key?(func_name)
          @functions[func_name].call(*args)
        else
          raise "Undefined function: #{func_name}"
        end
      when :+, :-, :*, :/, :%
        left = evaluate(expression[1])
        right = evaluate(expression[2])
        left.send(expression[0], right)
      else
        raise "Unknown expression: #{expression.inspect}"
      end
    else
      raise "Unknown expression: #{expression.inspect}"
    end
  end
end
